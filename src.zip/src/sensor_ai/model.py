"""Two-branch PyTorch regression model for paired sensor measurements."""
import torch
from torch import nn

class FusionNet(nn.Module):
    def __init__(self, hidden=48):
        super().__init__()
        self.sers = nn.Sequential(nn.Linear(128,hidden),nn.ReLU(),nn.Linear(hidden,24),nn.ReLU())
        self.electro = nn.Sequential(nn.Linear(64,hidden),nn.ReLU(),nn.Linear(hidden,24),nn.ReLU())
        self.head = nn.Sequential(nn.Linear(48,32),nn.ReLU(),nn.Linear(32,3),nn.Sigmoid())

    def forward(self, sers, electrochemical):
        if sers.ndim != 2 or electrochemical.ndim != 2 or sers.shape[1]!=128 or electrochemical.shape[1]!=64 or len(sers)!=len(electrochemical):
            raise ValueError('Expected aligned [batch,128] and [batch,64] inputs')
        return self.head(torch.cat([self.sers(sers),self.electro(electrochemical)],dim=1))
