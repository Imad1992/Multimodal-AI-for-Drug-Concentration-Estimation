"""Evolutionary deconvolution against a documented synthetic forward model."""
import numpy as np
from scipy.optimize import differential_evolution
from .simulation import simulate

def deconvolve(sers, electrochemical, seed=42, maxiter=80):
    s=np.asarray(sers,dtype=float);e=np.asarray(electrochemical,dtype=float)
    if s.shape!=(128,) or e.shape!=(64,) or not np.isfinite(s).all() or not np.isfinite(e).all():
        raise ValueError('Expected one finite SERS(128) and electrochemical(64) measurement')
    # Recover fixed synthetic basis from noiseless generator design; no clinical calibration.
    x=np.linspace(0,1,128);v=np.linspace(-1,1,64)
    bs=np.stack([np.exp(-((x-.24)/.045)**2)+.65*np.exp(-((x-.66)/.06)**2),
       .85*np.exp(-((x-.42)/.055)**2)+.5*np.exp(-((x-.78)/.035)**2),
       .7*np.exp(-((x-.31)/.07)**2)+np.exp(-((x-.87)/.045)**2)])
    be=np.stack([np.exp(-((v+.5)/.18)**2),-.8*np.exp(-((v-.05)/.22)**2),1.1*np.exp(-((v-.55)/.16)**2)])
    def objective(c):
        # remove fixed baseline term; nuisance offsets estimated by centering residuals
        rs=s-c@bs-.03*x;re=e-c@be
        return float(np.mean((rs-rs.mean())**2)+np.mean((re-re.mean())**2))
    result=differential_evolution(objective,[(.05,1)]*3,seed=seed,maxiter=maxiter,popsize=8,polish=True)
    return {'concentrations':result.x.tolist(),'loss':float(result.fun),'success':bool(result.success)}
