"""Generate synthetic paired Raman-like and electrochemical-like measurements.
These are mathematical demonstrations, NOT measured or calibrated clinical signals.
"""
import numpy as np

N_ANALYTES = 3
SERS_POINTS = 128
EC_POINTS = 64

def simulate(n=600, seed=42, noise=0.035):
    if n < 1 or noise < 0:
        raise ValueError("n must be positive and noise nonnegative")
    rng = np.random.default_rng(seed)
    concentrations = rng.uniform(0.05, 1.0, (n, N_ANALYTES)).astype('float32')
    x = np.linspace(0, 1, SERS_POINTS)
    v = np.linspace(-1, 1, EC_POINTS)
    sers_basis = np.stack([
        np.exp(-((x-.24)/.045)**2) + .65*np.exp(-((x-.66)/.06)**2),
        .85*np.exp(-((x-.42)/.055)**2) + .5*np.exp(-((x-.78)/.035)**2),
        .7*np.exp(-((x-.31)/.07)**2) + np.exp(-((x-.87)/.045)**2),
    ])
    ec_basis = np.stack([
        np.exp(-((v+.5)/.18)**2),
        -0.8*np.exp(-((v-.05)/.22)**2),
        1.1*np.exp(-((v-.55)/.16)**2),
    ])
    sers = concentrations @ sers_basis + rng.normal(0,noise,(n,SERS_POINTS))
    ec = concentrations @ ec_basis + rng.normal(0,noise,(n,EC_POINTS))
    # Baseline shifts mimic instrument drift; NOT a validated physical sensor model.
    sers += rng.normal(0, .025, (n,1)) + .03*x[None,:]
    ec += rng.normal(0,.02,(n,1))
    return sers.astype('float32'), ec.astype('float32'), concentrations

def save_dataset(path, n=600, seed=42):
    from pathlib import Path
    path = Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    s,e,y=simulate(n,seed)
    np.savez_compressed(path, sers=s, electrochemical=e, concentrations=y)
    return path

def load_dataset(path):
    with np.load(path,allow_pickle=False) as d:
        s,e,y=d['sers'],d['electrochemical'],d['concentrations']
    if s.ndim != 2 or e.ndim != 2 or y.ndim != 2 or s.shape[1] != 128 or e.shape[1] != 64 or y.shape[1] != 3 or len(s)!=len(e) or len(s)!=len(y):
        raise ValueError('Invalid paired sensor dataset shapes')
    if not all(np.isfinite(a).all() for a in (s,e,y)):
        raise ValueError('Non-finite dataset values')
    return s,e,y
