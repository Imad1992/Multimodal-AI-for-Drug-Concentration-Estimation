"""Reproducible train/evaluate/predict pipeline. Train-only standardisation."""
import json
from pathlib import Path
import numpy as np
import torch
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from .simulation import load_dataset
from .model import FusionNet

def train(data_path='data/synthetic_sensors.npz', output='artifacts', epochs=45, seed=42):
    if epochs < 1: raise ValueError('epochs must be positive')
    torch.manual_seed(seed)
    torch.set_num_threads(1)
    s,e,y=load_dataset(data_path)
    ids=np.arange(len(y))
    tr,te=train_test_split(ids,test_size=.2,random_state=seed)
    tr,va=train_test_split(tr,test_size=.2,random_state=seed)
    ss=StandardScaler().fit(s[tr]); es=StandardScaler().fit(e[tr])
    s=ss.transform(s).astype('float32');e=es.transform(e).astype('float32')
    model=FusionNet(); opt=torch.optim.Adam(model.parameters(),lr=.002)
    loss_fn=torch.nn.MSELoss()
    def tens(ix): return torch.from_numpy(s[ix]),torch.from_numpy(e[ix]),torch.from_numpy(y[ix])
    a,b,t=tens(tr); av,bv,tv=tens(va)
    best=float('inf'); best_state=None; history=[]
    for epoch in range(epochs):
        model.train()
        for batch in torch.randperm(len(tr)).split(64):
            opt.zero_grad(); loss=loss_fn(model(a[batch],b[batch]),t[batch]);loss.backward();opt.step()
        model.eval()
        with torch.no_grad(): val=loss_fn(model(av,bv),tv).item()
        history.append({'epoch':epoch+1,'validation_mse':val})
        if val < best:
            best=val;best_state={k:v.detach().clone() for k,v in model.state_dict().items()}
    model.load_state_dict(best_state); model.eval()
    with torch.no_grad(): pred=model(torch.from_numpy(s[te]),torch.from_numpy(e[te])).numpy()
    metrics={'mae':float(mean_absolute_error(y[te],pred)),
             'rmse':float(np.sqrt(mean_squared_error(y[te],pred))),
             'r2':float(r2_score(y[te],pred)),
             'test_samples':int(len(te)), 'train_samples':int(len(tr)),
             'validation_samples':int(len(va)), 'epochs':epochs,
             'per_analyte_mae':[float(v) for v in np.mean(abs(y[te]-pred),axis=0)]}
    out=Path(output);out.mkdir(parents=True,exist_ok=True)
    torch.save(best_state,out/'fusion_model.pt')
    np.savez(out/'scalers.npz',s_mean=ss.mean_,s_scale=ss.scale_,e_mean=es.mean_,e_scale=es.scale_)
    (out/'metrics.json').write_text(json.dumps(metrics,indent=2))
    (out/'history.json').write_text(json.dumps(history,indent=2))
    return metrics

def predict(sers,electrochemical,artifacts='artifacts'):
    s=np.asarray(sers,dtype='float32');e=np.asarray(electrochemical,dtype='float32')
    if s.ndim!=2 or e.ndim!=2 or s.shape[1]!=128 or e.shape[1]!=64 or len(s)!=len(e) or not np.isfinite(s).all() or not np.isfinite(e).all():
        raise ValueError('Invalid input shapes or values')
    folder=Path(artifacts)
    with np.load(folder/'scalers.npz',allow_pickle=False) as z:
        s=(s-z['s_mean'])/z['s_scale'];e=(e-z['e_mean'])/z['e_scale']
    model=FusionNet()
    model.load_state_dict(torch.load(folder/'fusion_model.pt',map_location='cpu',weights_only=True))
    model.eval()
    with torch.no_grad():return model(torch.tensor(s,dtype=torch.float32),torch.tensor(e,dtype=torch.float32)).numpy()
