import numpy as np
import pytest
from sensor_ai.simulation import simulate,save_dataset,load_dataset
from sensor_ai.model import FusionNet
from sensor_ai.pipeline import train,predict
from sensor_ai.optimisation import deconvolve
import torch

def test_simulator_reproducible():
    a=simulate(4,seed=8);b=simulate(4,seed=8)
    assert all(np.array_equal(x,y) for x,y in zip(a,b))
    assert a[0].shape==(4,128) and a[1].shape==(4,64) and a[2].shape==(4,3)

def test_invalid_inputs():
    with pytest.raises(ValueError):simulate(0)
    with pytest.raises(ValueError):deconvolve(np.zeros(4),np.zeros(64))
    with pytest.raises(ValueError):FusionNet()(torch.zeros(2,100),torch.zeros(2,64))

def test_training_and_inference(tmp_path):
    f=save_dataset(tmp_path/'demo.npz',n=70)
    s,e,y=load_dataset(f)
    metrics=train(f,tmp_path/'models',epochs=2)
    assert metrics['test_samples']==14
    p=predict(s[:3],e[:3],tmp_path/'models')
    assert p.shape==(3,3) and np.isfinite(p).all()

def test_optimisation_finite():
    s,e,_=simulate(1,seed=9)
    result=deconvolve(s[0],e[0],maxiter=2)
    assert len(result['concentrations'])==3 and np.isfinite(result['loss'])
