# Architecture

1. **Data layer:** reproducible paired synthetic SERS-like (128 points) and electrochemical-like (64 points) arrays with three normalised targets.
2. **Validation:** finite values, fixed channel lengths and aligned samples.
3. **Training:** deterministic train/validation/test split; feature scalers fitted on training samples only; separate dense encoders followed by fusion regression.
4. **Optimisation:** differential evolution minimises residuals of the synthetic forward sensor model, with nuisance baseline offsets removed by centring.
5. **Serving:** Streamlit exploratory interface and FastAPI JSON endpoint. API is intended for local demonstration, not public deployment.
6. **Reproducibility:** JSON metrics, training history, model weights and scalers; unit tests and CI.

## Known limitations

- Synthetic basis functions are mathematical approximations, not experimentally validated SERS or electrochemical response functions.
- Concentrations are dimensionless and do not correspond to therapeutic ranges.
- No patient data, no clinical calibration, no uncertainty quantification or external validation.
- Real deployment requires rigorous data provenance, governance, secure authentication, hardware integration, cross-instrument validation, regulatory review, and expert oversight.
- Optimiser and neural network are complementary independent baselines, not a proven hybrid model.
