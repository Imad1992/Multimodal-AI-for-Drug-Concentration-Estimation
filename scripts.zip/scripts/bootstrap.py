"""Create a reproducible dataset and fit the model."""
from sensor_ai.simulation import save_dataset
from sensor_ai.pipeline import train
if __name__=='__main__':
    path=save_dataset('data/synthetic_sensors.npz',n=650)
    print('Generated',path)
    print('Evaluation:',train(path))
