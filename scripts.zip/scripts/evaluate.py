import json
from pathlib import Path
if __name__=='__main__':
    p=Path('artifacts/metrics.json')
    if not p.exists(): raise SystemExit('Run python -m scripts.bootstrap first')
    print(json.dumps(json.loads(p.read_text()),indent=2))
